from flask import Flask, render_template, request
from transformers import pipeline, set_seed

app = Flask(__name__)

# Load GPT-2 text generation pipeline
generator = pipeline("text-generation", model="gpt2")
set_seed(42)

@app.route("/", methods=["GET", "POST"])
def index():
    result = ""
    if request.method == "POST":
        prompt = request.form["prompt"]
        content_type = request.form["type"]

        # Add prompt context
        if content_type == "Story":
            full_prompt = f"Once upon a time, {prompt}"
        else:
            full_prompt = f"A beautiful poem about {prompt}:\n"

        try:
            output = generator(full_prompt, max_length=150, num_return_sequences=1)
            result = output[0]["generated_text"].strip()
        except Exception as e:
            result = f"Error: {str(e)}"
    
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
